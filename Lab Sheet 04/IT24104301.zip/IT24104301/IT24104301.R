#Labsheet 04
#Exercises

#Q1
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")
fix(branch_data)
attach(branch_data)

#Q3
boxplot(branch_data$Sales_x1, main = "Sales distribution", outline=TRUE, 
        outpch=8, horizontal = TRUE, col="lightblue")

#Q4
fivenum(branch_data$Advertising_x2)
summary(branch_data$Advertising_x2)
IQR(branch_data$Advertising_x2)

#Q5
find_outliers <- function(x) {
  q1 <- quantile(x,0.25)
  q3 <- quantile(x,0.75)
  iqr <- q3 - q1
  ub <- q3 + 1.5 * iqr
  lb <- q1 - 1.5 * iqr
  outliers <- x[x < lb | x > ub]
  return(outliers)
}

# Check for outliers in Years
find_outliers(branch_data$Years_x3)
